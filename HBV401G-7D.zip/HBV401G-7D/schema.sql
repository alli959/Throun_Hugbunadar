//Bæta við Guide string
CREATE TABLE tours(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price REAL,
    date TEXT,
    location TEXT,
    host TEXT,
    category INTEGER REFERENCES categories(id),
    maxPeople INTEGER,
    info TEXT
);

CREATE TABLE categories(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL
);

Vantar að bæta þessu í DB!
CREATE TABLE reviews(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reviewText TEXT NOT NULL,
    tour INTEGER REFERENCES tours(id),
    author TEXT REFERENCES users(name),
    likes INTEGER
);

CREATE TABLE users(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    mail TEXT,
    phone TEXT
);

CREATE TABLE bookings(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tour INTEGER REFERENCES tours(id),
    user INTEGER REFERENCES users(id)
);

CREATE TABLE likes(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    review INTEGER REFERENCES review(id),
    user INTEGER REFERENCES users(id)
);
