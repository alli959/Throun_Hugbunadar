import org.junit.*;
import org.junit.Test;

import static org.junit.Assert.*;

public class UserControllerTest {

    private User user1, user2;
    private UserController uc = new UserController();

    @Before
    public void setUp() throws Exception {
        user1 = new User(0, "phh4@hi.is", "111", "Gummi", null );
        user2 = new User(0, "bull@hi.is", "222", "Skarphéðinn", null );
        uc.addUser(user1);
    }

    @After
    public void tearDown() throws Exception {
        uc.removeUser(user1);
        user1 = null;
        user2 = null;
    }

    @Test
    public void userAddTest() throws Exception {
        assertEquals(user1.getUserName(), uc.getUser(user1.getUserName()).getUserName());
    }

    @Test
    public void userGetTest() throws Exception {
        assertEquals(user1.getUserName(), uc.getUser(user1.getUserName()).getUserName());
    }

    @Test
    public void userRemoveTest() throws Exception {
        uc.addUser(user2);
        uc.removeUser(user2);
        User us = null;
        try {
            us = uc.getUser(user2.getUserName());
        } catch (Exception e) {
            System.err.println("User not found: " + e.getMessage());
        }
        assertNull(us);
    }

}