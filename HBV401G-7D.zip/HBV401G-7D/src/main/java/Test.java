import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

public class Test {
    public static void main(String[] args) throws Exception {
        Location location = new Location("Reykjavík", 112, "Dalhús");
        Date date = new Date();
        ArrayList<User> users = new ArrayList<>();
        ArrayList<Review> reviews = new ArrayList<>();
        ArrayList<Booking> bookings = new ArrayList<>();
        User guide = new User(3, "ids", "7439", "Guide", bookings);
        Tour tour = new Tour(
                1,
                "Jöklaferð",
                1000.2,
                date,
                "Reykjavík",
                "Fyrirtæki",
                "Halli",
                "Jokull",
                users,
                reviews,
                4,
                "Ferð a langjokul"
                );
        Booking booking = new Booking(1, tour, "Ingi", "ingi@gmail.com", true, location);
        System.out.println(tour.getTourName());


        UserController uc = new UserController();
        //boolean us = uc.removeUser(guide);
        //boolean us = uc.addUser(guide);
        //System.out.println(us);

        TourController tc = new TourController();
        Date d1 = new Date(2017-1900, 03, 16, 4, 30);
        Date d2 = new Date(2017-1900, 03, 16, 6, 30);
        ArrayList<Tour> b = tc.getAllTours();
        System.out.println(b.get(0).getTourName());
        //Review rw = rc.getReviewsForTour();
    }
}
